
function Title(props) {
    return(
        <>
                <div  style={{textAlign:"center"}}>
                    <h3 >{props.name}</h3>
                    
                </div>
          
        </>
    )
}
export default Title;

/* CREATED BY :

1. Lakshmi Radha Yashwanth Uppuganti - 1001964009
2. Bhargava Manikanta Aditya Tummalapenta - 1001965491
3. Sravani Ravipati - 1001949731 */ 