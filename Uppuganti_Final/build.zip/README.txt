1. Open the folder in a code editor
2. Open terminal and press the following commands:
	1. cd "path of the folder"
	2. npm install
	3. npm start
3. Navigate through the website